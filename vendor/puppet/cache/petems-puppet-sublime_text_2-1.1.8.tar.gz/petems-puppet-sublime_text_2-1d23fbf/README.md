# Sublime Text 2 Puppet Module for Boxen

## Usage

```puppet
include sublime_text_2
```

### User settings and keybindings

Add your custom settings and keybindings to the template files.

## Required Puppet Modules

None.
